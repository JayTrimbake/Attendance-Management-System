<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

// Handle adding a new class
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_class'])) {
    $class_name = $conn->real_escape_string($_POST['class_name']);
    $sql = "INSERT INTO classes (class_name) VALUES ('$class_name')";
    if ($conn->query($sql) === TRUE) {
        $class_message = "New class added successfully!";
    } else {
        $class_error = "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Handle adding a new student
$class_sql = "SELECT * FROM classes";
$class_result = $conn->query($class_sql);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_student'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $class_id = (int) $_POST['class_id'];
    $roll_no = (int) $_POST['roll_no'];
    $sql = "INSERT INTO students (name, class_id, roll_no) VALUES ('$name', $class_id, $roll_no)";
    if ($conn->query($sql) === TRUE) {
        $student_message = "New student added successfully!";
    } else {
        $student_error = "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
</head>
<body>
    <div class="sidebar">
        <h1>Admin Panel</h1>
        <a href="view_attendance.php">View Attendance</a>
        <a href="index.php">Mark Attendance</a>
        <a href="logout.php" class="logout">Log Out</a>
    </div>
    <div class="main-content">
        <div class="card">
            <h2>Add New Class</h2>
            <?php if (isset($class_message)) { echo "<p style='color: green;'>$class_message</p>"; } ?>
            <?php if (isset($class_error)) { echo "<p style='color: red;'>$class_error</p>"; } ?>
            <form method="POST" action="admin_panel.php">
                <label>Class Name:</label>
                <input type="text" name="class_name" required>
                <button type="submit" name="add_class">Add Class</button>
            </form>
        </div>
        <div class="card">
            <h2>Add New Student</h2>
            <?php if (isset($student_message)) { echo "<p style='color: green;'>$student_message</p>"; } ?>
            <?php if (isset($student_error)) { echo "<p style='color: red;'>$student_error</p>"; } ?>
            <form method="POST" action="admin_panel.php">
                <label>Name:</label>
                <input type="text" name="name" required>
                <label>Class:</label>
                <select name="class_id" required>
                    <option value="">Select Class</option>
                    <?php while ($class = $class_result->fetch_assoc()) { ?>
                    <option value="<?php echo $class['id']; ?>"><?php echo $class['class_name']; ?></option>
                    <?php } ?>
                </select>
                <label>Roll No:</label>
                <input type="number" name="roll_no" required>
                <button type="submit" name="add_student">Add Student</button>
            </form>
        </div>
    </div>
</body>
</html>
