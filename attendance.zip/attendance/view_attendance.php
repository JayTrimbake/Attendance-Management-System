<?php
include 'db.php';

$class_sql = "SELECT * FROM classes";
$class_result = $conn->query($class_sql);

$class_id = isset($_GET['class_id']) ? $_GET['class_id'] : 0;

$attendance_sql = "
    SELECT a.date, s.roll_no, s.name, c.class_name, a.status
    FROM attendance a
    JOIN students s ON a.student_id = s.id
    JOIN classes c ON s.class_id = c.id
    WHERE ($class_id = 0 OR c.id = $class_id)
    ORDER BY a.date, c.class_name, s.roll_no";
$attendance_result = $conn->query($attendance_sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Attendance Records</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <h1>Attendance Records</h1>
    <form method="GET" action="">
        <label>Class:</label>
        <select name="class_id" onchange="this.form.submit()">
            <option value="0">All Classes</option>
            <?php while ($class = $class_result->fetch_assoc()) { ?>
            <option value="<?php echo $class['id']; ?>" <?php if ($class_id == $class['id']) echo 'selected'; ?>><?php echo $class['class_name']; ?></option>
            <?php } ?>
        </select>
    </form>
    <table>
        <tr>
            <th>Date</th>
            <th>Roll No</th>
            <th>Name</th>
            <th>Class</th>
            <th>Status</th>
        </tr>
        <?php while ($row = $attendance_result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['roll_no']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['class_name']; ?></td>
            <td><?php echo $row['status']; ?></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
